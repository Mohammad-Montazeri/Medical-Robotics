clc;
clear;
close all;
%% defining constant parameters 
global r1 r3 r5 r7
global Pt Pp Ps
r1=0.19; 
r3=0.45;  
r5=0.5;  
r7=0.18;  
Pt = [0.25 0.75 0.3]; 
Pp = [0.17 0.4 0.5]; 
Ps = [0 0 0.19];  
%% defining path parameters
n=1000; 
s=linspace(75,83,n); 
Pe = zeros(4,n); 
Pw = zeros(4,n);
Pe(4,:) = 1;
Pw(4,:) = 1;
eq1 = zeros(1,n);
eq2 = zeros(1,n);
eq3 = zeros(1,n);
eq4 = zeros(1,n);
eq5 = zeros(1,n);
eq6 = zeros(1,n);
%initial condition
x0 = [0 0 0 0 0 0 0];

for i=1:n
    Pt = [25 s(i) 30]*0.01;
    options = optimoptions('fsolve','Algorithm','Levenberg-Marquardt','MaxFunctionEvaluations',10000);
    [x,fval] = fsolve(@equations,x0,options);
    Pe(1:3,i) = x(1:3);
    Pw(1:3,i) = x(4:6);
    q2(i) = acos((Pe(3,i)-r1)/r3);
    q1(i) = atan2(Pe(2,i)/(r3*sin(q2(i))),Pe(1,i)/(r3*sin(q2(i))));
    Pw2 = inv(Rot('z',q1(i))*Trans('z',r1)*Rot('x', 3*pi/2)*Rot('z',q2(i))*Rot('x', pi/2)) * Pw(:,i);
    q4(i) = acos((Pw2(3)-r3)/r5);
    q3(i) = atan2(Pw2(2)/(r5*sin(q4(i))),Pw2(1)/(r5*sin(q4(i))));
    b=ones(4,1);
    b(1:3) = Pt;
    Pt4 = inv(Rot('z',q1(i))*Trans('z',r1)*Rot('x', 3*pi/2)*Rot('z',q2(i))*Rot('x', pi/2)* ...
        Rot('z',q3(i))*Trans('z',r3)*Rot('x', 3*pi/2)*Rot('z',q4(i))*Rot('x', pi/2)) * b;
    q6(i) = acos((Pt4(3)-r5)/r7);
    q5(i) = atan2(Pt4(2)/(r7*sin(q6(i))),Pt4(1)/(r7*sin(q6(i))));
    x0 = x;

end

%% Plot Result
subplot(3,2,1)
plot(s,rad2deg(q1))
xlabel('s(cm)')
ylabel('q_1(deg)')
title('q_1(s)')
grid on

subplot(3,2,2)
plot(s,rad2deg(q2))
xlabel('s(cm)')
ylabel('q_2(deg)')
title('q_2(s)')
grid on

subplot(3,2,3)
plot(s,rad2deg(q3),'g')
xlabel('s(cm)')
ylabel('q_3(deg)')
title('q_3(s)')
grid on

subplot(3,2,4)
plot(s,rad2deg(q4),'g')
xlabel('s(cm)')
ylabel('q_4(deg)')
title('q_4(s)')
grid on

subplot(3,2,5)
plot(s,rad2deg(q5),'r')
xlabel('s(cm)')
ylabel('q_5(deg)')
title('q_5(s)')
grid on

subplot(3,2,6)
plot(s,rad2deg(q6),'r')
xlabel('s(cm)')
ylabel('q_6(deg)')
title('q_6(s)')
grid on

%% defining the equations to find x1 through x7
function F = equations(x)
global r1 r3 r5 r7
global Pt Pp Ps
Pe = [x(1) x(2) x(3)];
Pw = [x(4) x(5) x(6)];

F(1) = norm(Pe-Ps)^2 - r3^2;
F(2) = norm(Pw-Pt)^2 - r7^2;
F(3) = norm(Pe-Pw)^2 - r5^2;
F(4) = Pp(1)-x(1) - x(7)*(x(4)-x(1));
F(5) = Pp(2)-x(2) - x(7)*(x(5)-x(2));
F(6) = Pp(3)-x(3) - x(7)*(x(6)-x(3));
F(7) = norm(Pe-Pp) + norm(Pp-Pw) - r5;
end
