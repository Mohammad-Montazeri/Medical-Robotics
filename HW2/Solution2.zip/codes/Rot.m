function R = Rot(axis, angle)
%{
-----------------------------------------------------------------------
 Robotics HomeWork#1 Solution
 Spring 2022

 Provided By: Ehsan Tahvilian
 M.Sc. Student @ Sharif University of Technology

 contact e-mail: ehsantahvilian.robotics@gmail.com
-----------------------------------------------------------------------
%}
    %Homogeneous rotation about "axis" for the amount of "angle"
    axis = upper(axis); 
    
    if (axis == 'X') 
        R = [1   0           0          0;
             0  cos(angle) -sin(angle)  0;
             0  sin(angle)  cos(angle)  0;
             0   0           0          1]; 
    elseif (axis == 'Y') 
        R = [cos(angle)  0  sin(angle)  0;
              0          1   0          0;
            -sin(angle)  0  cos(angle)  0;
              0          0   0          1]; 
    elseif (axis =='Z') 
        R = [cos(angle) -sin(angle)  0  0;
             sin(angle)  cos(angle)  0  0;
              0           0          1  0;
              0           0          0  1];
    else
        error('The "axis" parameter (first input) of the function should be ''x'', ''y'', or ''z''.');
    end
    R = round(R, 4);
end