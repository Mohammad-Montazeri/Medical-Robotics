function T = Trans(axis, distance)
%{
-----------------------------------------------------------------------
 Robotics HomeWork#1 Solution
 Spring 2022

 Provided By: Ehsan Tahvilian
 M.Sc. Student @ Sharif University of Technology

 contact e-mail: ehsantahvilian.robotics@gmail.com
-----------------------------------------------------------------------
%}
    %Homogeneous transformation along "axis" for the amount of "distance"
    axis = upper(axis); 
    
    if (axis == 'X') 
        T = [1 0 0 distance;
             0 1 0    0    ;
             0 0 1    0    ;
             0 0 0    1     ]; 
    elseif (axis == 'Y') 
        T = [1 0 0    0    ;
             0 1 0 distance;
             0 0 1    0    ;
             0 0 0    1    ]; 
    elseif (axis =='Z') 
        T = [1 0 0    0    ;
             0 1 0    0    ;
             0 0 1 distance;
             0 0 0    1    ];
    else
        error('The "axis" parameter (first input) of the function should be ''x'', ''y'', or ''z''.');
    end
end